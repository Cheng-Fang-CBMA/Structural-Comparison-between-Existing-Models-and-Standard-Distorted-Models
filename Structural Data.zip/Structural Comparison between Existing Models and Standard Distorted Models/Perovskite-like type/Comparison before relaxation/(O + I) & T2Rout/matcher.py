from pymatgen.core.structure import IStructure,Structure
from pymatgen.analysis.structure_matcher import StructureMatcher,SpeciesComparator,SpinComparator,FrameworkComparator
#prim_struc1 = IStructure.from_file('88366.cif',primitive = True)
#prim_struc2 = IStructure.from_file('cal02.cif',primitive = True)
#match = prim_struc1.matches(prim_struc2)
#print match
struc1 = Structure.from_file('80055.cif',primitive = False)#.as_dict()
struc2 = Structure.from_file('POSCAR.cif',primitive = False)#.as_dict()
species =SpeciesComparator()
species_equal = species.are_equal(struc1,struc2)#compare whether they have the same speices
fram = FrameworkComparator()
fram_equal = fram.are_equal(struc1,struc2)#
struc_matcher = StructureMatcher()
supercell_size = struc_matcher._get_supercell_size(struc1,struc2)
get_lattice = struc_matcher._get_lattices(struc1,struc2)
fit = struc_matcher.fit(struc1,struc2)
print"If fit,True will be return,otherwise,False will be return:",fit
rms_dist = struc_matcher.get_rms_dist(struc1,struc2)# Calculate RMS displacement between two structures,rms displacement normalized by (Vol / nsites) ** (1/3) and maximum distance between paired sites. If no matching lattice is found None is returned.
print "RMS displacement between two structure is:",rms_dist
anony_fit = struc_matcher.fit_anonymous(struc1,struc2)
print"If anonymous fit,True will be return,otherwise,False will be return:",anony_fit#Performs an anonymous fitting, which allows distinct species in one structure to map to another. E.g., to compare if the Li2O and Na2O
preprocess = struc_matcher._preprocess(struc1,struc2)
fu = preprocess[2] # size of supercell to create
match = struc_matcher._match(struc1,struc2,fu)
print "The match result is:",match  #None means not matched
s_list = [struc1,struc2]
group_struc = struc_matcher.group_structures(s_list)
#print "A list of lists of matched structures:",group_struc #Assumption: if s1 == s2 but s1 != s3, than s2 and s3 will be put in different groups without comparison.this is helpful for many structures match
anony_match = struc_matcher._anonymous_match(struc1,struc2,fu,s1_supercell=False)
#print anony_match
